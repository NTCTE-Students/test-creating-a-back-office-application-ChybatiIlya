<php artisan orchid:install
 php artisan migrate 
php artisan make:migration create_users_table --create=users
php artisan make:migration create_clients_table --create=clients
php artisan make:migration create_orders_table --create=orders
php artisan make:migration create_inventory_table --create=inventory
php artisan make:migration create_order_items_table --create=order_items
php artisan make:migration create_finances_table --create=finances
php artisan make:migration create_notifications_table --create=notifications
php artisan make:migration create_email_logs_table --create=email_logs>

// users migration
Schema::create('users' function (Blueprint $table) {
$table->id();
$table->string('username')->unique();
$table->string('password');
$table->enum('role', ['admin', 'manager', 'employee']);
$table->timestamps();
}); 

// clients migration
Schema::create('clients', function (Blueprint $table) {
$table->id();
$table->string('name');
$table->string('email')->unique();
$table->string('phone')->nullable();
$table->string('address')->nullable();
$table->date('last_contact_date')->nullable();
$table->timestamps();
});

// orders migration
Schema::create('orders', function (Blueprint $table) {
$table->id();
$table->foreignId('client_id')->constrained();
$table->date('order_date');
$table->enum('status', ['pending', 'processed', 'shipped', 'delivered', 'canceled']);
$table->decimal('total', 10, 2);
$table->timestamps();
});

// inventory migration
Schema::create('inventory', function (Blueprint $table) {
$table->id();
$table->string('item_name');
$table->text('description')->nullable();
$table->integer('quantity');
$table->decimal('price', 10, 2);
$table->integer('alert_threshold');
$table->timestamps();
});

// order_items migration
Schema::create('order_items', function (Blueprint $table) {
$table->id();
$table->foreignId('order_id')->constrained();
$table->foreignId('item_id')->constrained('inventory');
$table->integer('quantity');
$table->timestamps();
});

// finances migration
Schema::create('finances', function (Blueprint $table) {
$table->id();
$table->foreignId('user_id')->constrained();
$table->foreignId('order_id')->nullable()->constrained();
$table->date('transaction_date');
$table->enum('type', ['income', 'expense']);
$table->decimal('amount', 10, 2);
$table->text('description')->nullable();
$table->timestamps();
});

// notifications migration
Schema::create('notifications', function (Blueprint $table) {
$table->id();
$table->foreignId('user_id')->constrained();
$table->foreignId('client_id')->nullable()->constrained();
$table->foreignId('order_id')->nullable()->constrained();
$table->text('message');
$table->timestamp('sent_at')->useCurrent();
$table->timestamps();
});

// email_logs migration

Schema::create('email_logs', function (Blueprint $table) {
$table->id();
$table->foreignId('user_id')->constrained();
$table->foreignId('client_id')->nullable()->constrained();
$table->string('subject');
$table->text('body');
$table->timestamp('sent_at')->useCurrent();
$table->timestamps();
});
php artisan migrate
